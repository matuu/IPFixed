/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Excepcion;

/**
 *
 * @author matuuar
 */
public class ExceptionIPFixed extends Exception {

    public ExceptionIPFixed(String message) {
        super(message);
    }

    public ExceptionIPFixed(Throwable cause) {
        super(cause);
    }
    
}
